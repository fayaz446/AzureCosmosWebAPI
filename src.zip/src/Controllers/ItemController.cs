﻿namespace todo.Controllers
{
    using System;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Mvc;
    using Models;

    public class ItemController : Controller
    {
        private readonly ICosmosDbService _cosmosDbService;
        public ItemController(ICosmosDbService cosmosDbService)
        {
            _cosmosDbService = cosmosDbService;
        }

     
      

        [HttpPost("Create")]      
        
        public async Task<string> CreateAsync( [FromBody()]Item item)
        {
            
                item.Id = Guid.NewGuid().ToString();
                await _cosmosDbService.AddItemAsync(item);
                return "Created successfully";
          
        }

        [HttpPost("Update")]
        
        public async Task<string> EditAsync([FromBody()] Item item)
        {
           
                await _cosmosDbService.UpdateItemAsync(item.Id, item);
                
             return "Updated successfully";
        }

        
        [HttpDelete("Delete/{Id}")]
        
        public async Task<string> DeleteConfirmedAsync(string id)
        {
            await _cosmosDbService.DeleteItemAsync(id);
            return "Deleted successfully";
        }

           [HttpGet("/Select/{Id}")]
        public async Task<Item> DetailsAsync(string Id)
        {
            return await _cosmosDbService.GetItemAsync(Id);
        }
    }
}